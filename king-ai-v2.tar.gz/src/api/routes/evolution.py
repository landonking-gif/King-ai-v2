"""
Evolution Routes - Management of self-modification proposals.
"""

from fastapi import APIRouter, HTTPException
from src.database.connection import get_db
from src.database.models import EvolutionProposal, EvolutionStatus
from sqlalchemy import select

router = APIRouter()

@router.get("/proposals")
async def list_proposals():
    """Returns all system evolution proposals."""
    async with get_db() as db:
        result = await db.execute(
            select(EvolutionProposal).order_by(EvolutionProposal.created_at.desc())
        )
        return result.scalars().all()

@router.get("/proposals/{proposal_id}")
async def get_proposal(proposal_id: str):
    """Returns details for a specific evolution proposal."""
    async with get_db() as db:
        prop = await db.get(EvolutionProposal, proposal_id)
        if not prop:
            raise HTTPException(status_code=404, detail="Proposal not found")
        return prop
