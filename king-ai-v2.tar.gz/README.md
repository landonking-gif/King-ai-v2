# King AI v2 - Autonomous Business Empire

See implementation_plan.md in the .gemini artifacts folder for complete build instructions.

## Quick Start

```bash
cp .env.example .env
docker-compose up -d
alembic upgrade head
uvicorn src.api.main:app --reload
```
